<?php
class WPBakeryShortCode_VC_Dropcaps extends WPBakeryShortCode {

}