<?php
class WPBakeryShortCode_VC_Magic_Image extends WPBakeryShortCode {

}